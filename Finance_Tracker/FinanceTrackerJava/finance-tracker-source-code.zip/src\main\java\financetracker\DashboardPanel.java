package financetracker;

import javax.swing.*;
import java.awt.*;
import java.time.YearMonth;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Modern dashboard with summary cards, spending bars, and recent activity. */
public class DashboardPanel extends JPanel {
    private final MainFrame frame;
    private final JPanel cards = new JPanel(new GridLayout(2, 3, 16, 16));
    private final JPanel categories = new JPanel();
    private final JPanel recent = new JPanel();

    /** Creates the dashboard. */
    public DashboardPanel(MainFrame frame) {
        this.frame = frame; setLayout(new BorderLayout(16, 16)); setBackground(Theme.CONTENT);
        JPanel page = new JPanel(new BorderLayout(0, 18)); page.setOpaque(false); page.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        page.add(header("Welcome back", "Here is your personal finance overview for " + LocalDate.now() + "."), BorderLayout.NORTH);
        cards.setOpaque(false); page.add(cards, BorderLayout.CENTER);
        JPanel lower = new JPanel(new GridLayout(1, 2, 16, 16)); lower.setOpaque(false);
        lower.add(section("Top 3 Spending Categories", categories)); lower.add(section("Recent Transactions", recent)); page.add(lower, BorderLayout.SOUTH);
        add(page);
    }

    /** Refreshes dashboard content. */
    public void refresh(List<Transaction> transactions) {
        cards.removeAll();
        long income = frame.reportService().totalIncome(transactions), expense = frame.reportService().totalExpense(transactions);
        List<Transaction> month = transactions.stream().filter(t -> YearMonth.from(t.getDate()).equals(YearMonth.now())).toList();
        card("↗", "Total Income", CurrencyUtil.formatINR(income), Theme.INCOME);
        card("↘", "Total Expense", CurrencyUtil.formatINR(expense), Theme.EXPENSE);
        card("=", "Net Balance", CurrencyUtil.formatINR(income - expense), Theme.ACCENT);
        card("◷", "This Month Income", CurrencyUtil.formatINR(frame.reportService().totalIncome(month)), Theme.INCOME);
        card("◷", "This Month Expense", CurrencyUtil.formatINR(frame.reportService().totalExpense(month)), Theme.EXPENSE);
        card("#", "Transactions", Integer.toString(transactions.size()), Theme.ACCENT);
        categories.removeAll(); categories.setLayout(new BoxLayout(categories, BoxLayout.Y_AXIS));
        Map<String, Long> totals = frame.reportService().categoryTotals(transactions);
        long maximum = totals.values().stream().mapToLong(Long::longValue).max().orElse(1);
        for (Map.Entry<String, Long> entry : frame.reportService().topThreeCategories(transactions)) {
            JPanel row = new JPanel(new BorderLayout(8, 3)); row.setOpaque(false);
            JLabel label = new JLabel(entry.getKey() + "  " + CurrencyUtil.formatINR(entry.getValue())); label.setFont(Theme.BODY);
            JProgressBar bar = new JProgressBar(0, 100); bar.setValue((int) (entry.getValue() * 100 / maximum)); bar.setForeground(Theme.ACCENT); bar.setStringPainted(false);
            row.add(label, BorderLayout.NORTH); row.add(bar, BorderLayout.CENTER); categories.add(row); categories.add(Box.createVerticalStrut(8));
        }
        if (totals.isEmpty()) categories.add(empty("◌  No expense data yet."));
        recent.removeAll(); recent.setLayout(new BoxLayout(recent, BoxLayout.Y_AXIS));
        transactions.stream().limit(5).forEach(t -> { JLabel item = new JLabel(t.getDate() + "   " + t.getCategory() + "   " + CurrencyUtil.formatINR(t.getAmount())); item.setFont(Theme.BODY); item.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0)); recent.add(item); });
        if (transactions.isEmpty()) recent.add(empty("◌  No transactions yet."));
        cards.revalidate(); cards.repaint(); categories.revalidate(); recent.revalidate();
    }

    private void card(String icon, String title, String value, Color color) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(8, 4));
        JLabel iconLabel = new JLabel(icon); iconLabel.setForeground(color); iconLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JLabel titleLabel = new JLabel(title); titleLabel.setForeground(Theme.MUTED); titleLabel.setFont(Theme.BODY);
        JLabel valueLabel = new JLabel(value); valueLabel.setForeground(Theme.TEXT); valueLabel.setFont(Theme.VALUE);
        card.add(iconLabel, BorderLayout.WEST); JPanel text = new JPanel(new GridLayout(2, 1)); text.setOpaque(false); text.add(titleLabel); text.add(valueLabel); card.add(text);
        cards.add(card);
    }

    private JPanel section(String title, JPanel body) { RoundedPanel card = new RoundedPanel(new BorderLayout(0, 12)); JLabel heading = new JLabel(title); heading.setFont(Theme.BOLD); card.add(heading, BorderLayout.NORTH); card.add(body); return card; }
    private JLabel header(String title, String subtitle) { JLabel label = new JLabel("<html><font size='6'>" + title + "</font><br><font color='#6B7280'>" + subtitle + "</font></html>"); label.setFont(Theme.TITLE); return label; }
    private JLabel empty(String text) { JLabel label = new JLabel(text); label.setForeground(Theme.MUTED); return label; }
}
