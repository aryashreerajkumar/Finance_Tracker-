package financetracker;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

/** Main application window and refresh coordinator for all tabs. */
public class MainFrame extends JFrame {
    private final Database database;
    private final ReportService reports = new ReportService();
    private final DashboardPanel dashboard;
    private final TransactionFormPanel form;
    private final ManagePanel manage;
    private final SummaryPanel summary;
    private final ReportsPanel charts;
    private final ExportPanel export;
    private final JPanel content = new JPanel(new CardLayout());
    private final Map<String, JButton> navigation = new LinkedHashMap<>();
    private final JLabel status = new JLabel(" ");

    /** Creates the database and all application tabs. */
    public MainFrame() throws SQLException {
        super("FinTrack - Smart Personal Finance");
        database = new Database();
        Theme.install();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        dashboard = new DashboardPanel(this);
        form = new TransactionFormPanel(this);
        manage = new ManagePanel(this);
        summary = new SummaryPanel(this);
        charts = new ReportsPanel(this);
        export = new ExportPanel(this);
        content.add(dashboard, "Dashboard"); content.add(form, "Add Transaction");
        content.add(manage, "Manage Transactions"); content.add(summary, "Monthly Summary");
        content.add(charts, "Visual Reports"); content.add(export, "Export");
        add(createSidebar(), BorderLayout.WEST); add(content, BorderLayout.CENTER);
        refreshAll();
        showPage("Dashboard");
    }

    /** Returns the shared database. */
    public Database database() { return database; }
    /** Returns the shared reporting service. */
    public ReportService reportService() { return reports; }

    /** Refreshes every view after a data change. */
    public void refreshAll() {
        try {
            List<Transaction> transactions = database.all();
            dashboard.refresh(transactions);
            manage.refresh();
            summary.refresh();
            charts.refresh(transactions);
            export.refresh();
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    /** Displays a consistent database error dialog. */
    public void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE);
    }

    /** Shows a form validation error. */
    public void showValidation(String message) {
        JOptionPane.showMessageDialog(this, message, "Please check your input", JOptionPane.WARNING_MESSAGE);
    }

    /** Shows a page selected from the sidebar. */
    public void showPage(String page) {
        ((CardLayout) content.getLayout()).show(content, page);
        for (Map.Entry<String, JButton> entry : navigation.entrySet()) {
            entry.getValue().setBackground(entry.getKey().equals(page) ? Theme.ACCENT : Theme.SIDEBAR);
            entry.getValue().setForeground(entry.getKey().equals(page) ? Color.WHITE : Theme.TEXT);
        }
    }

    /** Shows a non-blocking success message in the content shell. */
    public void showSuccess(String message) { status.setText(message); status.setForeground(Theme.INCOME); }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout(0, 12));
        sidebar.setBackground(Theme.SIDEBAR); sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Theme.BORDER));
        JPanel top = new JPanel(); top.setOpaque(false); top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        JLabel logo = new JLabel("  FinTrack"); logo.setFont(new Font("Segoe UI", Font.BOLD, 25)); logo.setForeground(Theme.ACCENT);
        JLabel tagline = new JLabel("  Smart Personal Finance"); tagline.setFont(new Font("Segoe UI", Font.PLAIN, 11)); tagline.setForeground(Theme.MUTED);
        top.add(Box.createVerticalStrut(24)); top.add(logo); top.add(tagline); top.add(Box.createVerticalStrut(28));
        String[] pages = {"Dashboard", "Add Transaction", "Manage Transactions", "Monthly Summary", "Visual Reports", "Export"};
        String[] icons = {"⌂", "+", "▤", "▥", "◔", "⇧"};
        for (int i = 0; i < pages.length; i++) {
            JButton item = new JButton(icons[i] + "   " + pages[i]); item.setHorizontalAlignment(SwingConstants.LEFT);
            item.setFont(Theme.BODY); item.setFocusPainted(false); item.setBorder(BorderFactory.createEmptyBorder(11, 18, 11, 10));
            item.setOpaque(true); item.setBackground(Theme.SIDEBAR); item.setForeground(Theme.TEXT);
            final String page = pages[i]; item.addActionListener(e -> showPage(page)); navigation.put(page, item); top.add(item);
        }
        sidebar.add(top, BorderLayout.NORTH);
        JPanel bottom = new JPanel(); bottom.setOpaque(false); bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        JButton seed = new JButton("＋  Load Sample Data"); Theme.secondary(seed); seed.setAlignmentX(Component.CENTER_ALIGNMENT);
        seed.addActionListener(e -> { try { SeedData.load(database); refreshAll(); showSuccess("Sample data loaded successfully."); } catch (Exception ex) { showError(ex); } });
        JLabel version = new JLabel("v1.0"); version.setForeground(Theme.MUTED); version.setAlignmentX(Component.CENTER_ALIGNMENT);
        bottom.add(seed); bottom.add(Box.createVerticalStrut(12)); bottom.add(version); bottom.add(Box.createVerticalStrut(18)); sidebar.add(bottom, BorderLayout.SOUTH);
        return sidebar;
    }
}
