package financetracker;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import java.awt.*;

/** Central visual language for the FinTrack light theme. */
public final class Theme {
    public static final Color CONTENT = Color.decode("#F5F7FB");
    public static final Color SIDEBAR = Color.WHITE;
    public static final Color ACCENT = Color.decode("#5B5BD6");
    public static final Color INCOME = Color.decode("#16A34A");
    public static final Color EXPENSE = Color.decode("#DC2626");
    public static final Color TEXT = Color.decode("#1F2937");
    public static final Color MUTED = Color.decode("#6B7280");
    public static final Color BORDER = Color.decode("#E5E7EB");
    public static final Font BODY = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BOLD = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font TITLE = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font VALUE = new Font("Segoe UI", Font.BOLD, 22);

    private Theme() { }

    /** Applies global FlatLaf component properties and table defaults. */
    public static void install() {
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 12);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("Component.focusColor", ACCENT);
        UIManager.put("TextField.margin", new Insets(8, 12, 8, 12));
        UIManager.put("ComboBox.padding", new Insets(6, 10, 6, 10));
        UIManager.put("Table.rowHeight", 34);
        UIManager.put("Table.showHorizontalLines", false);
        UIManager.put("Table.showVerticalLines", false);
        UIManager.put("Table.alternateRowColor", Color.decode("#FAFBFF"));
        UIManager.put("TableHeader.background", Color.decode("#EEF1F7"));
        UIManager.put("TableHeader.foreground", TEXT);
        UIManager.put("TableHeader.font", BOLD);
    }

    /** Styles a primary action button. */
    public static void primary(JButton button) {
        button.putClientProperty("JButton.buttonType", "roundRect");
        button.setBackground(ACCENT);
        button.setForeground(Color.WHITE);
        button.setFont(BOLD);
        button.setBorder(new EmptyBorder(10, 18, 10, 18));
    }

    /** Styles a secondary action button. */
    public static void secondary(JButton button) {
        button.putClientProperty("JButton.buttonType", "roundRect");
        button.setFont(BOLD);
        button.setBorder(new EmptyBorder(9, 15, 9, 15));
    }

    /** Applies the common table presentation. */
    public static void table(JTable table) {
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFont(BODY);
        JTableHeader header = table.getTableHeader();
        header.setFont(BOLD);
        header.setPreferredSize(new Dimension(0, 38));
    }
}
