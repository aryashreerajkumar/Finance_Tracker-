package financetracker;

import org.jfree.chart.*;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.awt.Color;
import java.awt.Font;

/** Builds the pie, bar, and line charts used by the reports tab. */
public class ChartService {
    /** Creates a spending-by-category pie chart. */
    public JFreeChart createPieChart(Map<String, Long> totals) {
        DefaultPieDataset<String> dataset = new DefaultPieDataset<>();
        totals.forEach(dataset::setValue);
        JFreeChart chart = ChartFactory.createPieChart("Spending by Category", dataset, true, true, false);
        chart.setBackgroundPaint(Color.WHITE);
        PiePlot<?> plot = (PiePlot<?>) chart.getPlot(); plot.setBackgroundPaint(Color.WHITE); plot.setOutlineVisible(false);
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: ₹{1}"));
        return chart;
    }

    /** Creates a monthly income versus expense bar chart. */
    public JFreeChart createBarChart(Map<YearMonth, long[]> monthly) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        monthly.forEach((month, values) -> { dataset.addValue(values[0], "Income", month.toString()); dataset.addValue(values[1], "Expense", month.toString()); });
        JFreeChart chart = ChartFactory.createBarChart("Monthly Income vs Expense", "Month", "Amount (₹)", dataset);
        chart.setBackgroundPaint(Color.WHITE); CategoryPlot plot = (CategoryPlot) chart.getPlot(); plot.setBackgroundPaint(Color.WHITE); plot.setOutlineVisible(false);
        plot.getRangeAxis().setLabelFont(new Font("Segoe UI", Font.PLAIN, 12)); plot.getRenderer().setSeriesPaint(0, Theme.INCOME); plot.getRenderer().setSeriesPaint(1, Theme.EXPENSE);
        return chart;
    }

    /** Creates a line chart showing balance trend by month. */
    public JFreeChart createLineChart(Map<YearMonth, long[]> monthly) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        long balance = 0;
        for (Map.Entry<YearMonth, long[]> entry : monthly.entrySet()) {
            balance += entry.getValue()[0] - entry.getValue()[1];
            dataset.addValue(balance, "Balance", entry.getKey().toString());
        }
        JFreeChart chart = ChartFactory.createLineChart("Balance Trend", "Month", "Amount (₹)", dataset);
        chart.setBackgroundPaint(Color.WHITE); CategoryPlot plot = (CategoryPlot) chart.getPlot(); plot.setBackgroundPaint(Color.WHITE); plot.setOutlineVisible(false); plot.getRenderer().setSeriesPaint(0, Theme.ACCENT);
        return chart;
    }
}
