package financetracker;

import org.jfree.chart.ChartPanel;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

/** Tab containing pie, bar, and line visual reports. */
public class ReportsPanel extends JPanel {
    private final MainFrame frame;
    private final JPanel charts = new JPanel(new GridLayout(1, 3, 16, 16));
    private final JTextField from = new JTextField(10), to = new JTextField(10);
    private final JComboBox<String> category = new JComboBox<>(new String[]{"All","Food","Travel","Rent","Bills","Shopping","Health","Entertainment","Education","Salary","Other"});
    private final JComboBox<String> type = new JComboBox<>(new String[]{"All","Income","Expense"});

    /** Creates the reports panel. */
    public ReportsPanel(MainFrame frame) {
        this.frame = frame; setLayout(new BorderLayout(16, 16)); setBackground(Theme.CONTENT); setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        JPanel filters = new JPanel(); filters.setBackground(Color.WHITE); filters.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12)); filters.add(new JLabel("From")); filters.add(from); filters.add(new JLabel("To")); filters.add(to);
        filters.add(new JLabel("Category")); filters.add(category); filters.add(new JLabel("Type")); filters.add(type);
        JButton apply = new JButton("Apply Filters"); Theme.primary(apply); filters.add(apply); apply.addActionListener(e -> refreshFromFilters());
        add(filters, BorderLayout.NORTH); add(charts, BorderLayout.CENTER);
    }

    /** Rebuilds all charts from the supplied filtered dataset. */
    public void refresh(List<Transaction> transactions) {
        ChartService service = new ChartService(); charts.removeAll();
        charts.setOpaque(false);
        charts.add(chartCard("Spending", service.createPieChart(frame.reportService().categoryTotals(transactions))));
        charts.add(chartCard("Monthly", service.createBarChart(frame.reportService().monthlySummary(transactions))));
        charts.add(chartCard("Balance Trend", service.createLineChart(frame.reportService().monthlySummary(transactions))));
    }

    private JPanel chartCard(String title, org.jfree.chart.JFreeChart chart) {
        RoundedPanel card = new RoundedPanel(new BorderLayout());
        JLabel heading = new JLabel(title); heading.setFont(Theme.BOLD); card.add(heading, BorderLayout.NORTH);
        ChartPanel chartPanel = new ChartPanel(chart); chartPanel.setBorder(BorderFactory.createEmptyBorder()); card.add(chartPanel, BorderLayout.CENTER);
        return card;
    }

    /** Rebuilds charts from this tab's selected filters. */
    private void refreshFromFilters() {
        try {
            LocalDate start = from.getText().isBlank() ? null : Validator.parseDate(from.getText());
            LocalDate end = to.getText().isBlank() ? null : Validator.parseDate(to.getText());
            if (start != null && end != null && start.isAfter(end)) throw new IllegalArgumentException("From date must not be after To date.");
            refresh(frame.database().query(start, end, (String) category.getSelectedItem(), (String) type.getSelectedItem()));
        } catch (IllegalArgumentException ex) { frame.showValidation(ex.getMessage()); } catch (Exception ex) { frame.showError(ex); }
    }
}
